// CPathSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CPathSample.h"
#include "CPathSampleDlg.h"
#include "Path.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCPathSampleDlg dialog

CCPathSampleDlg::CCPathSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCPathSampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCPathSampleDlg)
	m_bHasArg = FALSE;
	m_bIsFolder = FALSE;
	m_sPath = _T("x:\\folder\\filetitle.ext");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCPathSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCPathSampleDlg)
	DDX_Control(pDX, IDC_LIST, m_list);
	DDX_Check(pDX, IDC_CKHASARG, m_bHasArg);
	DDX_Check(pDX, IDC_CKISFOLDER, m_bIsFolder);
	DDX_Text(pDX, IDC_EDITPATH, m_sPath);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCPathSampleDlg, CDialog)
	//{{AFX_MSG_MAP(CCPathSampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnSetPath)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCPathSampleDlg message handlers

BOOL CCPathSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_list.SetFont(GetFont());
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES);
	m_list.InsertColumn(0, "Info", LVCFMT_LEFT, 150, 0);
	m_list.InsertColumn(1, "Value", LVCFMT_LEFT, 350, 1);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCPathSampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCPathSampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCPathSampleDlg::OnSetPath() 
{
	CPath	p;
	CString	s;
	
	UpdateData();

	p.SetPath(m_sPath, m_bIsFolder, m_bHasArg);

	m_list.DeleteAllItems();
	AddPair("GetLongPath", p.GetLongPath());
	AddPair("GetShortPath", p.GetShortPath());
	AddPair("GetDrive", p.GetDrive());
	AddPair("GetDriveLabel", p.GetDriveLabel());
	AddPair("GetDir", p.GetDir());
	AddPair("GetDirCount", (long)p.GetDirCount());
	AddPair("GetLocation", p.GetLocation());
	AddPair("GetFileName", p.GetFileName());
	AddPair("GetFileTitle", p.GetFileTitle());
	AddPair("GetExtension", p.GetExtension());
	AddPair("GetExtName", p.GetExtName());
	AddPair("GetArgument", p.GetArgument());
	AddPair("GetArgCount", (long)p.GetArgCount());

	AddPair("IsFilePath", p.IsFilePath());
	AddPair("IsLocalPath", p.IsLocalPath());
	AddPair("IsRelativePath", p.IsRelativePath());
	AddPair("ExistFile", p.ExistFile());
	AddPair("ExistLocation", p.ExistLocation());

	__int64 nFileSize;
	p.GetFileSize(nFileSize);
	AddPair("GetFileSize (bytes)", (long)nFileSize);
	CTime time;
	p.GetFileTime(time, FILE_CREATION);
	AddPair("GetFileTime (creation)", time);
	p.GetFileTime(time, FILE_WRITE);
	AddPair("GetFileTime(write)", time);
	p.GetFileTime(time, FILE_ACCESS);
	AddPair("GetFileTime(access)", time);
}

void CCPathSampleDlg::AddPair(LPCTSTR szInfo, LPCTSTR szValue)
{
	int nItem = m_list.InsertItem(m_list.GetItemCount(), szInfo);
	m_list.SetItemText(nItem, 1, szValue);
}

void CCPathSampleDlg::AddPair(LPCTSTR szInfo, BOOL bValue)
{
	AddPair(szInfo, bValue? "TRUE" : "FALSE");
}

void CCPathSampleDlg::AddPair(LPCTSTR szInfo, long nValue)
{
	CString s;
	s.Format("%ld", nValue);
	AddPair(szInfo, s);
}

void CCPathSampleDlg::AddPair(LPCTSTR szInfo, CTime &time)
{
	AddPair(szInfo, time.FormatGmt("%c"));
}
